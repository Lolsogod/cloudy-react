import React from "react";

export const FilesPage = () =>{
    return(
        <div>
            <h1>All Files:</h1>
        </div>
    )
}