import React from "react";

export const UploadPage = () =>{
    return(
        <div>
            <h1>Upload</h1>
            <button>upload</button>
        </div>
    )
}