import React from "react";

import './App.css';
import {useRoutes} from "./routes";

function App() {
    const routes = useRoutes(false)
  return (

        <div className="container">
          <h1>CloudY</h1>
            {routes}
        </div>

  );
}

export default App;
