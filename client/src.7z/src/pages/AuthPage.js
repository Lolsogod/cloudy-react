import React from "react";

export const AuthPage = () =>{
    return(
        <div>
            <h1>Auth Page!</h1>
        </div>
    )
}